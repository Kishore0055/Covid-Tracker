import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor
import joblib  # For older scikit-learn versions, use 'from sklearn.externals import joblib'

def prediction(State, Date):
    # Load the dataset
    df = pd.read_csv('encoded_data.csv')

    # Preprocess the data
    df['Date'] = pd.to_datetime(df[['year', 'month', 'day']])
    df = df.drop(['year', 'month', 'day'], axis=1)

    # Extract additional date features
    df['DayOfWeek'] = df['Date'].dt.dayofweek
    df['DayOfMonth'] = df['Date'].dt.day
    df['Month'] = df['Date'].dt.month

    # Convert 'Death' column to numeric, handling non-numeric values
    df['Death'] = pd.to_numeric(df['Death'], errors='coerce')

    # Drop rows with NaN values in the target variable
    df.dropna(subset=['Death'], inplace=True)

    # Create features and labels
    features = ['Name of State / UT', 'Latitude', 'Longitude', 'DayOfWeek', 'DayOfMonth', 'Month']
    labels_death = 'Death'
    labels_recovery = 'Cured/Discharged/Migrated'
    labels_new_cases = 'New cases'

    X_death = df[features].copy()
    X_recovery = df[features].copy()
    X_new_cases = df[features].copy()

    y_death = df[labels_death].copy()
    y_recovery = df[labels_recovery].copy()
    y_new_cases = df[labels_new_cases].copy()

    # Convert categorical features to numerical using one-hot encoding
    X_death = pd.get_dummies(X_death, columns=['Name of State / UT'])
    X_recovery = pd.get_dummies(X_recovery, columns=['Name of State / UT'])
    X_new_cases = pd.get_dummies(X_new_cases, columns=['Name of State / UT'])

    # Ensure the columns match between training and prediction datasets
    missing_cols_death = set(X_death.columns) - set(X_death.columns)
    missing_cols_recovery = set(X_recovery.columns) - set(X_recovery.columns)
    missing_cols_new_cases = set(X_new_cases.columns) - set(X_new_cases.columns)

    for col in missing_cols_death:
        X_death[col] = 0

    for col in missing_cols_recovery:
        X_recovery[col] = 0

    for col in missing_cols_new_cases:
        X_new_cases[col] = 0

    # Split the data into training and testing sets
    X_death_train, X_death_test, y_death_train, y_death_test = train_test_split(X_death, y_death, test_size=0.2, random_state=42)
    X_recovery_train, X_recovery_test, y_recovery_train, y_recovery_test = train_test_split(X_recovery, y_recovery, test_size=0.2, random_state=42)
    X_new_cases_train, X_new_cases_test, y_new_cases_train, y_new_cases_test = train_test_split(X_new_cases, y_new_cases, test_size=0.2, random_state=42)

    # Train Decision Tree models
    model_death = DecisionTreeRegressor(random_state=42)
    model_recovery = DecisionTreeRegressor(random_state=42)
    model_new_cases = DecisionTreeRegressor(random_state=42)

    model_death.fit(X_death_train, y_death_train)
    model_recovery.fit(X_recovery_train, y_recovery_train)
    model_new_cases.fit(X_new_cases_train, y_new_cases_train)

    # Save the trained models
    joblib.dump(model_death, 'model_death.joblib')
    joblib.dump(model_recovery, 'model_recovery.joblib')
    joblib.dump(model_new_cases, 'model_new_cases.joblib')

    # Load the saved models
    model_death = joblib.load('model_death.joblib')
    model_recovery = joblib.load('model_recovery.joblib')
    model_new_cases = joblib.load('model_new_cases.joblib')

    # User input for prediction
    input_state = State
    input_date_str = Date
    input_date = pd.to_datetime(input_date_str)

    input_features_death = pd.DataFrame([[input_state, 0, 0, input_date.dayofweek, input_date.day, input_date.month]], columns=['Name of State / UT', 'Latitude', 'Longitude', 'DayOfWeek', 'DayOfMonth', 'Month'])
    input_features_recovery = input_features_death.copy()
    input_features_new_cases = input_features_death.copy()

    # One-hot encode 'State' column
    input_features_death = pd.get_dummies(input_features_death, columns=['Name of State / UT'])
    input_features_recovery = pd.get_dummies(input_features_recovery, columns=['Name of State / UT'])
    input_features_new_cases = pd.get_dummies(input_features_new_cases, columns=['Name of State / UT'])

    # Ensure the columns match
    for col in missing_cols_death:
        input_features_death[col] = 0

    for col in missing_cols_recovery:
        input_features_recovery[col] = 0

    for col in missing_cols_new_cases:
        input_features_new_cases[col] = 0

    # Ensure columns order matches
    input_features_death = input_features_death.reindex(columns=X_death.columns, fill_value=0)
    input_features_recovery = input_features_recovery.reindex(columns=X_recovery.columns, fill_value=0)
    input_features_new_cases = input_features_new_cases.reindex(columns=X_new_cases.columns, fill_value=0)

    predicted_death = model_death.predict(input_features_death)
    predicted_recovery = model_recovery.predict(input_features_recovery)
    predicted_new_cases = model_new_cases.predict(input_features_new_cases)

    return predicted_death[0], predicted_recovery[0], predicted_new_cases[0]