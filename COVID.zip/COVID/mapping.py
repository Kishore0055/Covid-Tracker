import pandas as pd
import folium
import matplotlib.pyplot as plt

# Read the dataset
df = pd.read_csv('encoded_data.csv')

# Create a Folium map centered at the mean latitude and longitude
map_center = [df['Latitude'].mean(), df['Longitude'].mean()]
mymap = folium.Map(location=map_center, zoom_start=5)

# Add markers for each state
for index, row in df.iterrows():
    tooltip_text = f"{row['Name of State / UT']}\nTotal Cases: {row['Total Confirmed cases']}\nDeaths: {row['Death']}\nRecovered: {row['Cured/Discharged/Migrated']}"
    folium.Marker([row['Latitude'], row['Longitude']], tooltip=tooltip_text).add_to(mymap)

# Save the map as an HTML file
mymap.save('covid_map1.html')

# Create pie charts for each state
for index, row in df.iterrows():
    labels = ['Total Confirmed cases', 'Death', 'Cured/Discharged/Migrated']
    sizes = [row['Total Confirmed cases'], row['Death'], row['Cured/Discharged/Migrated']]
    plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=140)
    plt.title(row['Name of State / UT'])
    plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
    plt.savefig(f"{row['Name of State / UT']}_pie_chart.png")
    plt.clf()  # Clear the current figure

print("Pie charts saved as images.")

# Display the map in a web browser
import webbrowser
webbrowser.open('covid_map1.html')
